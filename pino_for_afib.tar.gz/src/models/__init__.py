from .fourier2d import FNO2d
from .fourier3d import FNO3d